function plot_eye(data, t_sym, offset)
%Function plot_eye plots an eye diagram for a time domain waveform
%Usage: plot_eye(data, t_sym, offset)
%   data: matrix containing the time domain waveform (multiple traces
%       supported by using multiple columns)
%   t_sys: symbol period in number of samples (can be fractional)
%   offset: number of samples to offset the diagram in order to center the
%       eye diagram.
[n_data, n_trace]=size(data);
figure; hold on;
for ind=1:n_trace
    plot(rem((0:n_data-1)+offset, t_sym),data(:,ind),'.', 'MarkerSize',1);
end
grid on;

