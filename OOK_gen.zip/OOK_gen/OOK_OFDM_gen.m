function [waveform, OFDM_symbs, OOK_per_OFDM, bit_repeat_pattern, bit_skip_pattern,cycshift_pattern] = OOK_OFDM_gen(info, M, Nifft, Nsc, Fr2d, start_ind)
% function OOK_OFDM_gen implements the M2-1-1 method for CP handling
% proposed by Futurewei Technologies in Ambient IoT work item of R19
% Usage: [waveform, OFDM_symbs, OOK_per_OFDM, bit_repeat_pattern, bit_skip_pattern,cycshift_pattern] = OOK_OFDM_gen(info, M, Nifft, Nsc, Fr2d, start_ind)
%   Inputs:
%       info:   array of binary information bits to be encoded as OOK symbols
%       M:      The number of OOK chips per OFDM symbol, supported values
%               are [4, 6, 8, 12, 16, 24, 32]
%       Nifft:   ifft size used to convert OFDM symbols into time domain
%               waveform
%       Nsc:    number of subcarriers allocated to R2D transmission
%       Fr2d:   starting index of subcarriers allocated to R2D transmission
%               within the total Nfft subcarriers (index starts at 0)
%       start_ind: index to the OFDM symbol to start the message. Its range
%               1 to 7. 1 means the message starts on the OFDM symbol with
%               the slightly longer CP. 
%   Outputs:
%       waveform:       time domain complex waveform
%       OFDM_symbs:     array of Nfft by the number of OFDM symbols
%                       containing the complex modulation values for all subcarriers
%       OOK_per_OFDM:   array of M by the number of OFDM symbols containing
%                       OOK symbol values
%       bit_repeat_pattern: {7,14} x2 vector containing the bit repeating pattern for 
%                       7 or 14 consecutive OFDM symbols. For each OFDM symbol, 
%                       the first number refers to index to the bit from
%                       previous symbol to be repeated, the second number refers to the index to
%                       the bit in current symbol that is repeating a bit in the previous symbol. 
%                       [0 0] denotes no bit repeating. 
%       bit_skip_pattern: array to indicate to the receiver which bits are
%                       to be skipped after bit detection. 0 means keep, 1 means skip.
%                       The pattern repeats.
%       cycshift_pattern: 7x1 vector containing the number of samples of
%                       cyclic shifts each OFDM symbol was subject to.
%                       Internally, the DFT size is assumed to be 384.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Sean Ma, sean.ma@futurewei.com
% Date: 2/28/2025, first version
% Date: 3/5/2025, Update Manchester encoding to 0->[1,0], 1->[0,1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if M==6 % special case since 14 symbols are needed to fit even number of information bits
    period=14;
else
    period=7; % number of OFDM symbols that fits integer number of information bits
end

Nfft=384; % FFT size used for OFDM signal generation

Nook=Nfft/M; % number of samples per OOK chip

Ninfo=length(info);
Nsym=floor(2*Ninfo/M*2); % number of OFDM symbols with extras.

info=[info(:);NaN(M/2*10,1)]; % padding info with NaNs as end of message indicator.

Ncp_l=circshift([30;27*ones(6,1)],-start_ind+1); %CP length in a 7 OFDM symbol period
Ncp=Nifft/2048*circshift([160;144*ones(6,1)], -start_ind+1); % CP length for ifft

if M==6 % special case since 14 symbols are needed to fit even number of information bits
    Ncp_l=[Ncp_l;Ncp_l];
    Ncp=[Ncp;Ncp];
end

% determine the cyclic shift pattern per 7 OFDM symbol.
cycshift_pattern=zeros(period,1);
for ind=1:period
    cycshift_pattern(ind)=mod(sum(Ncp_l(1:ind)),2*Nook );
end

% determine the repeat pattern for the information bit per OFMD symbol
% for each OFDM symbol, the first number refers to index to the bit from
% previous symbol to be repeated, the second number refers to the index to
% the bit in current symbol that is repeating a bit in previous symbol. 
% [0 0] denotes no bit repeating. 
bit_repeat_pattern=zeros(period, 2);  
for ind=2:period
    if cycshift_pattern(ind-1)==0 % the case when previous OFDM symbol was not cyclic shifted
    else
        %since the shift is limited to less than an information bit length,
        %the uncompleted information bit at the end of previous OFDM symbol is 
        %always the first one. 
        bit_repeat_pattern(ind,1)=1; 
        %the information bit in current symbol that repeats the bit in
        %previous symbol is the first one after cyclic shift that gets copied by the CP
        %insertion process and inserted in the beginning
        if Ncp_l(ind)-cycshift_pattern(ind)<0 
            % the case the first bit is connecting to the  
            % incomplete bit in the previous symbol
            bit_repeat_pattern(ind,2)=1;
        else
            % the case a bit at the end of the current symbol is connection
            % to the incomplete bit in the previous symbol
            bit_repeat_pattern(ind,2)=M/2-floor((Ncp_l(ind)-cycshift_pattern(ind))/Nook/2);
        end
    end
end

% Determine bit skip pattern at the receiver. 
bit_skip_pattern=zeros((Nfft*period+sum(Ncp_l))/2/Nook,1);
bit_ind=1;
for ind=1:period
    if bit_repeat_pattern(ind,1)==0 % the first OFDM symbol in a 7 or 14 symbol period
        if Ncp_l(ind)>2*Nook % At least 1 whole bit is in the CP. skip the bit at the end.
            bit_skip_pattern(bit_ind+M/2:bit_ind+M/2+floor(Ncp_l(ind)/2/Nook)-1)=1;
            bit_ind=bit_ind+M/2+floor(Ncp_l(ind)/2/Nook);
        else %no need to skip in the beginning
            bit_ind=bit_ind+M/2;
        end
    else
        if bit_repeat_pattern(ind,2)==1 %skip the beginning 
            bit_skip_pattern(bit_ind)=1;
            bit_ind=bit_ind+M/2;% set the index to the next symbol
        else  % skip the beginning bit, the repeating bit and any whole bit at the end that is inserted in the beginning
              % (this only occurs if the repeating bit is not the last bit)
            bit_skip_pattern(bit_ind)=1; % skip the beginning bit as it is completing a previous bit
            bit_ind=bit_ind+M/2; % index to the repeating bit
            bit_skip_pattern(bit_ind:bit_ind+M/2-bit_repeat_pattern(ind,2))=1; % skip the repeating bit and any following whole bi
            bit_ind=bit_ind+M/2-bit_repeat_pattern(ind,2)+1;
        end
    end
end

% Carrier frequency of the AIoT R2D signal
Fc=Nsc/2+Fr2d+1;
% modulate each symbol
OFDM_symbs=zeros(Nsc,Nsym); % modulated OFDM symbols in frequency domain
waveform=[]; % modulated waveform in time domain.
info_ind=1; %
info_bits=NaN(M/2, Nsym); % the bits actually modulated on the OFDM symbols. 
OOK_per_OFDM=zeros(M, Nsym); % the OOK symbols actually modulated on the OFDM sybmols.
end_ind=0; % The index of the last OFDM symbol with information.
phi=0; % phase compensation for each OFDM symbol
for ind=1: Nsym
    % calculate the infomation bits to be encoded in current symbol
    ind_pattern=mod(ind-1,period)+1;
    if bit_repeat_pattern(ind_pattern,1)==0 % first symbol in a 7 or 14 symbol period
        % since we are keeping the whole bits copied to the beginning and
        % skippin them in the end, any whole bits should be circularly
        % shifted to the back.
        if (Ncp_l(ind_pattern)>2*Nook)
            info_bits(:,ind)=circshift(info(info_ind:info_ind+M/2-1),-floor(Ncp_l(ind_pattern)/2/Nook));
        else
            info_bits(:,ind)=info(info_ind:info_ind+M/2-1);
        end
        info_ind=info_ind+M/2;
    else
        temp_info=info(info_ind:info_ind+M/2-2); % extract the information bits to be encoded.
        % repeat the information bit from previous OFDM symbol
        info_bits(bit_repeat_pattern(ind_pattern,2),ind)=info_bits(bit_repeat_pattern(ind_pattern,1),ind-1);
        if bit_repeat_pattern(ind_pattern,2)==1
            info_bits(2:end,ind)=temp_info;
        elseif bit_repeat_pattern(ind_pattern,2)==2
            info_bits(1:end-1,ind)=temp_info;
        else % the case where at least 1 full bit is in the CP
            temp_info=circshift(temp_info, -M/2+bit_repeat_pattern(ind_pattern,2)); % shift them to the end
            info_bits(1: bit_repeat_pattern(ind_pattern,2)-1, ind)=temp_info(1: bit_repeat_pattern(ind_pattern,2)-1);
            info_bits(bit_repeat_pattern(ind_pattern,2)+1:M/2, ind)=temp_info(bit_repeat_pattern(ind_pattern,2):end);
        end
        info_ind=info_ind+M/2-1;
    end
    % generate time domain waveform
    temp_info=reshape([1-info_bits(:,ind),info_bits(:,ind)]', M,1); % Manchester encoding 0->[1 0], 1->[0 1]
    if sum(isnan(temp_info)) %if NaN exists, it is the last symbol with information
        end_ind=ind;
        % end_bit_ind=find(isnan(temp_info)); % the index to the last bit of information
        % end_bit_ind=(end_bit_ind(1)-1)/2;
        % if the last bit is NaN, and it appears in the CP, then set it to 0, to ensure CP has meaningful
        % data
        if isnan(temp_info(end)) && cycshift_pattern(ind_pattern) < Ncp_l(ind_pattern) 
            temp_info(end-1:end)=[1;0];
        end
        temp_info(isnan(temp_info))=0; % turn all NaN into 0
    end
    OOK_per_OFDM(:,ind)=temp_info;
    wave_temp=kron(temp_info, ones(Nook,1));
    wave_temp=circshift(wave_temp, -cycshift_pattern(ind_pattern));
    % save the ideal waveform
    % generate OFDM symbol modulation values with compensating phase shift
    phi=mod(phi+1/Nfft*Fc*Ncp_l(ind_pattern),1);
    wave_temp_F=fft(wave_temp,Nfft)*exp(1i*2*pi*phi)*Nifft/Nfft; % scaling to preserve amplitude.
    % truncate to fit the spectral allocation
    wave_temp_F=fftshift(wave_temp_F);
    OFDM_symbs(:,ind)=wave_temp_F(Nfft/2-Nsc/2:Nfft/2+Nsc/2-1);
    % generate time domain waveform with cp insertion
    full_symbol=zeros(Nifft,1);
    full_symbol(Fr2d+(1:Nsc))=OFDM_symbs(:,ind);
    wave_temp_T=ifft(full_symbol, Nifft);
    waveform=[waveform; [wave_temp_T(end-Ncp(ind_pattern)+1:end); wave_temp_T]];
    if end_ind~=0 % stop encoding when message is finished
        break;
    end
end
% drop the extra symbols not modulated.
OFDM_symbs=OFDM_symbs(:,1:end_ind);
OOK_per_OFDM=OOK_per_OFDM(:,1:end_ind);
end